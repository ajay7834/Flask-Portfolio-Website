# Flask Portfolio Website

This is a simple portfolio website built using Flask.

## Features
- Homepage with personal info
- Contact form
- Flask routing and Jinja2 templates

## How to Run
```bash
pip install flask
python app.py
```
